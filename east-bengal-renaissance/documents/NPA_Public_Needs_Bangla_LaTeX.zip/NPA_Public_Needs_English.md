# Long-term Public Needs and Social Rights Programme
Personal proposal for discussion in the NPA Political Cell

Proposed by: Md. Ikramul Haq Khan
Date: 29 October 2026

Status: A personal discussion proposal, not an adopted or approved NPA position. The proposals below are normative options, not verified descriptions of current laws or government services.

## 1. Central idea
I propose a sustained programme of listening, public-interest research, policy development and peaceful civic participation around everyday problems.

Meaningful social change requires patience, consistent work and institutions that remain accountable between major political events. The starting question is: Which concrete changes would make people's lives safer, more dignified and economically secure?

Participation, assistance and access to public services must never depend on political membership, religious identity or agreement with an organisation.

Shared rights and needs should provide the foundation, with people identifying their own priorities. One person may simultaneously be a woman, an agricultural worker, a member of a religious minority and a consumer. Categories must not substitute for listening.

## 2. Shared principles
- Equal citizenship and freedom from discrimination.
- Decent work, fair compensation and economic security.
- Access to food, clothing, adequate housing, healthcare and education.
- Gender equality, accessibility for disabled people and protection from violence.
- Freedom of religion, conscience, cultural expression and peaceful association.
- Transparent public institutions and accountable use of public money.
- Environmental protection and resilience to disasters.

These rights are interconnected. Addressing one problem must not undermine another person's rights.

## 3. Areas for public consultation
The following are starting points for consultation, not assumptions that everyone within an identity category shares the same priorities.

### Migration and consular services
Investigate excessive recruitment costs, contract violations, unpaid wages, inaccessible consular support and unclear complaint procedures. Listen to the experiences of skilled and unskilled workers and other migrants.

Possible proposals: transparent recruitment charges; accessible complaint systems; published embassy and consular service standards and response times; legal assistance and emergency referral arrangements.

### Safe and accessible workplaces
Investigate unsafe or unhygienic toilets, harassment, unsafe workplaces and travel, and lack of childcare. Give proper attention to working women's experiences.

Possible proposals: clean, accessible toilets; confidential complaints and fair investigation; effective workplace safety rules; affordable daycare and safer travel.

### Childhood and public space
Investigate the lack of safe playgrounds and barriers to recreation.

Possible proposals: protect public playgrounds; provide safe access and maintenance budgets; include children with disabilities in facility design and use.

### Youth development
Investigate limited affordable opportunities in sports, arts, science and practical learning.

Possible proposals: accessible libraries, sports facilities, cultural programmes and laboratories, with transparent opportunities to participate in training.

### Employment conditions and stability
Investigate excessive hours, insecure contracts, unpaid overtime and arbitrary dismissal, including the experiences of private-office employees.

Possible proposals: clear written contracts; effective working-time rules; timely wages; fair grievance and termination procedures.

### Education and research
Investigate inadequate support for teaching, outdated curricula, limited laboratories and opaque research opportunities.

Possible proposals: periodic curriculum review; teacher development; functioning libraries and laboratories; transparent research funding and academic freedom. Listen to students, teachers and researchers.

### Low-paid and informal work
Investigate occupational injuries, unstable earnings and exclusion from social protection.

Possible proposals: sector-appropriate wage-setting; safety inspections; accessible injury compensation; portable social protection that continues across changes of employment.

### Agriculture and agricultural labour
Investigate low farm-gate prices, expensive inputs, storage losses and weak bargaining power.

Possible proposals: transparent market information; improved storage and transport; voluntary producer cooperatives; agricultural extension and accountable input assistance.

Assess small farmers, tenant farmers and agricultural labourers separately. Assistance for fertiliser, diesel, irrigation or pesticides should consider affordability, leakage, environmental effects and safe use.

### Prices and purchasing power
Investigate essential household expenses and earnings that cannot cover them.

Possible proposals: monitor household affordability; improve competition and supply systems; strengthen income opportunities and needs-based social protection.

### Small enterprises and fair business conditions
Investigate unpredictable fees, delayed payments, barriers to finance and unequal market access.

Possible proposals: transparent licensing; prompt payment procedures; fair access to procurement and finance; remedies for demonstrable anticompetitive conduct. Distinguish allegations from established misconduct.

### Indigenous peoples and cultural rights
Investigate barriers to language, cultural practice, public services and participation in decisions.

Possible proposals: community-led cultural preservation; language access; meaningful consultation; fair procedures for land-related grievances.

### Religion and conscience
Investigate discrimination, threats, unequal protection and weak institutional accountability.

Possible proposals: equal protection for all faiths and nonbelievers; transparent and accountable religious institutions; protection against coercion and abuse. Strong religious institutions should serve their communities while respecting equal citizenship and freedom of conscience.

### Basic living conditions
Investigate food insecurity, inadequate housing, unsafe water, sanitation gaps and barriers to healthcare.

Possible proposals: costed plans for essential services and social protection, with clear eligibility and accessible appeals.

## 4. Choosing priorities fairly
Do not promise to solve everything immediately. Select a small number of feasible issues using published criteria:

- Severity of harm and urgency.
- Priorities expressed by the people affected.
- Exclusion from existing services.
- Strength and limitations of the evidence.
- Whether an identifiable responsible institution can take a specific action.
- Expected cost, feasibility and unintended consequences.

Offer several ways to participate, including written submissions and accessible meetings. Attendance at an open meeting must not be treated as a representative survey. Record disagreement. Majority preferences cannot override fundamental rights.

## 5. From concerns to actionable proposals
Each selected issue should have a short public issue brief containing:

- The problem and who experiences it.
- What is verified, what is an allegation or personal account, and what remains uncertain.
- Existing services, responsibilities and gaps.
- A specific proposed remedy.
- The institution responsible for considering or implementing it.
- Expected costs and a plausible funding source.
- A realistic timetable and indicators of improvement.
- A complaint, appeal and review process.

For example, a public-toilet proposal should specify locations, accessibility, water supply, opening hours, maintenance responsibility and a recurring budget. Construction without maintenance will not solve the problem.

## 6. Participation and institutional accountability
People who experience a problem should help define it, assess solutions and evaluate results. Consultation must include people who disagree with us.

Any working group should have a written remit, limited terms, published responsibilities and a clear decision-recording process. Existing unions, professional associations, community groups and service providers should retain their independence.

Necessary safeguards include:

- Public financial reporting and conflict-of-interest declarations.
- Confidential handling of personal complaints.
- Consent before publishing names, photographs or testimonies.
- Fair hearings and proportionate responses to misconduct.
- Protection against harassment and retaliation.
- A clear separation between public assistance and political recruitment.

Information collected for complaints or service access must not become a political persuasion database.

## 7. Financing and economic fairness
I support examining progressive taxation so that people with greater ability to pay contribute more. A credible proposal must distinguish income, immovable property, net wealth, inheritance and business taxation.

Assess revenue potential, administrative capacity, avoidance, distributional effects and consequences for investment and employment. Effective collection and transparent spending are essential.

Identify initial and recurring costs separately. Agricultural assistance, childcare, public facilities and research funding require continuing resources. Commitments should be accompanied by financing estimates.

## 8. A bounded initial assessment
Consider a twelve-week consultation and policy-assessment process. This is a proposed timetable for discussion, not an approved organisational commitment.

### Weeks 1–2: Scope and rules
Agree on scope, participation rules, privacy protections and available time and capacity. Output: short public terms of reference.

### Weeks 3–5: Listening and evidence
Gather voluntary submissions and review existing evidence. Output: an anonymised account of needs and evidence gaps.

### Weeks 6–8: Assessing proposals
Review a small number of proposals with affected people and relevant specialists. Output: draft issue briefs identifying costs and responsibilities.

### Weeks 9–10: Criticism and revision
Invite disagreement and responses from responsible institutions. Output: published feedback and revisions.

### Weeks 11–12: Review
Assess feasibility and decide what merits continued attention. Output: a public assessment and a bounded next-stage plan.

Match scope to actual volunteer capacity. Agree on meeting time and responsibilities in advance. People must be able to pause or step back without penalty or pressure.

## 9. Defining success
Assess public benefit and accountability:

- Are services more accessible?
- Are complaints resolved more promptly and fairly?
- Have safety, affordability or working conditions improved?
- Are budgets and responsibilities clearer?
- Have previously excluded people gained a meaningful voice?
- Are mistakes acknowledged and corrected?

Meetings and reports matter when they help produce these outcomes. Specify indicator baselines, information sources and measurement dates. A before-and-after change alone does not establish that the programme caused the change.

My proposal is to make consistent attention to everyday needs, democratic participation and accountable institutions the foundation of this work. Make specific commitments, explain costs, welcome scrutiny and report honestly on what has and has not improved.

Editorial note: Prepared and organised with AI assistance from the author's original ideas. Decisions to adopt, amend or implement the proposal belong to the organisation's own democratic processes.
