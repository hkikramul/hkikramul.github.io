from pathlib import Path
import json,re,html,shutil,zipfile
root=Path('output/pdf');site=Path('website/making-sense');stem='NPA_Public_Needs_Bangla'
hist=json.loads(Path('proposal_history.json').read_text());sources=json.loads(Path('proposal_sources.json').read_text())
bn=(root/(stem+'.md')).read_text();en=(root/'NPA_Public_Needs_English.md').read_text()
intro={
'bn':'এই নির্বাচিত ইতিহাস বাংলাদেশের বর্তমান ভূখণ্ড, অবিভক্ত বাংলা, ভারতীয় উপমহাদেশ ও বিশ্বের কয়েকটি অভিজ্ঞতার পরিচিতি। এগুলো পূর্ণাঙ্গ ইতিহাস নয় এবং একই রাজনৈতিক মতাদর্শের উদাহরণও নয়। তথ্যভিত্তিক বিবরণের পর আলাদা করে পাঠের ব্যাখ্যা দেওয়া হয়েছে। কোনো আন্দোলনের ফলকে এক নেতা, এক কৌশল বা এক ঘটনার একমাত্র ফল বলা হচ্ছে না।',
'en':'These selected histories introduce experiences from present-day Bangladesh, undivided Bengal, the Indian subcontinent and other regions. They are neither an exhaustive history nor examples of one political ideology. Factual summaries are followed by separately labelled interpretations. No outcome is attributed exclusively to one leader, method or event.'}
synthesis={
'bn':'তুলনামূলক ব্যাখ্যা: দৈনন্দিন জীবনের প্রশ্ন, মর্যাদা ও প্রাতিষ্ঠানিক অধিকারের মধ্যে সংযোগ দেখা যায়। কিন্তু কেবল সফল ও পরিচিত উদাহরণ বাছলে ব্যর্থতা ও ক্ষতির ইতিহাস আড়াল হতে পারে। এসব ঘটনা প্রমাণ করে না যে একই পদ্ধতি অন্য দেশে একই ফল দেবে, কিংবা কোনো নির্দিষ্ট সংগঠনের জনপ্রিয়তা নিশ্চিত করবে। নিচের প্রস্তাব তাই স্বাধীন নীতিগত আলোচনার বিষয়; ঐতিহাসিক উৎসের লেখকেরা এটি অনুমোদন করেছেন, এমন দাবি নয়।',
'en':'Comparative interpretation: Everyday needs, dignity and institutional rights are often connected. Selecting familiar or successful cases can obscure failure and harm. These histories do not prove that the same approach will produce the same outcome elsewhere or guarantee any organisation’s popularity. The proposal below is an independent normative discussion, not a position endorsed by the historical sources.'}
def esc(s):
 return ''.join({'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}'}.get(c,c) for c in s)
def refs_tex(s):
 t=esc(s)
 return re.sub(r'\[([0-9,]+)\]',lambda m:'['+', '.join(r'\hyperlink{ref'+n+'}{'+n+'}' for n in m[1].split(','))+']',t)
def para(s):return refs_tex(s)+'\n\n'
def heading(s,level=1,mark=None):
 cmd='section' if level==1 else 'subsection'
 return ('\\pdfbookmark['+str(level)+']{'+esc(mark or s)+'}{mark'+str(heading.count)+'}\n' if mark else '')+'\\'+cmd+'*{'+esc(s)+'}\n'
heading.count=0
def h(s,level=1,mark=None):heading.count+=1;return heading(s,level,mark)
def mdtex(md,lang):
 out='';inside=False
 for line in md.splitlines():
  if inside and not line.startswith('- '):out+='\\end{itemize}\n';inside=False
  if line.startswith('# '):continue
  if line.startswith('## '):out+=h(line[3:],1,('BN ' if lang=='bn' else 'EN ')+line[3:])
  elif line.startswith('### '):out+=h(line[4:],2)
  elif line.startswith('- '):
   if not inside:out+='\\begin{itemize}\n';inside=True
   out+='\\item '+esc(line[2:])+'\n'
  elif line:out+=para(line)
 if inside:out+='\\end{itemize}\n'
 return out
tex=r'''\documentclass[11pt,a4paper]{article}
\usepackage[margin=23mm,headheight=16pt]{geometry}
\usepackage{fontspec}
\setmainfont{Latin Modern Roman}
\newfontfamily\bengalifont[Script=Bengali,Renderer=OpenType,BoldFont=BengaliSerif.ttf,BoldFeatures={FakeBold=1.4}]{BengaliSerif.ttf}
\newenvironment{bangla}{\par\bengalifont\fontsize{12.2}{19}\selectfont}{\par}
\usepackage{xcolor}
\definecolor{ink}{HTML}{173B46}
\usepackage{titlesec}
\titleformat{\section}{\Large\bfseries\color{ink}}{}{0pt}{}
\titleformat{\subsection}{\large\bfseries\color{ink}}{}{0pt}{}
\titlespacing*{\section}{0pt}{16pt}{8pt}
\titlespacing*{\subsection}{0pt}{8pt}{4pt}
\usepackage{enumitem}
\setlist[itemize]{leftmargin=17pt,itemsep=3pt,topsep=5pt,label=\textbullet}
\usepackage{fancyhdr}
\pagestyle{fancy}\fancyhf{}
\fancyhead[L]{\small Public Needs and Social Rights}
\fancyhead[R]{\small Personal discussion proposal}
\fancyfoot[C]{\small\thepage}
\usepackage{xurl}
\usepackage[unicode,colorlinks=true,urlcolor=ink,linkcolor=ink,bookmarksopen=true]{hyperref}
\hypersetup{pdftitle={Grassroots Histories, Public Needs and Social Rights - Bangla and English},pdfauthor={Md. Ikramul Haq Khan}}
\setlength{\parindent}{0pt}\setlength{\parskip}{7pt}
\linespread{1.17}\emergencystretch=3em
\raggedright\urlstyle{same}
\begin{document}
\thispagestyle{empty}
{\small\color{ink}NPA / POLITICAL DISCUSSION \quad | \quad BILINGUAL EDITION}\par
\vspace{14mm}
\begin{bangla}
{\fontsize{23}{32}\selectfont\bfseries\color{ink}তৃণমূল আন্দোলনের ইতিহাস, জনচাহিদা ও সামাজিক অধিকার\par}
\vspace{4mm}
{\large দীর্ঘমেয়াদি কর্মসূচি নিয়ে ব্যক্তিগত আলোচনার প্রস্তাব\par}
\end{bangla}
\vspace{7mm}
{\LARGE\bfseries\color{ink}Grassroots Histories, Public Needs and Social Rights\par}
\vspace{3mm}
{\large A personal proposal for a long-term public-needs programme\par}
\vspace{8mm}
{\bfseries Md. Ikramul Haq Khan}\par
\begin{bangla}মো. ইকরামুল হক খান\end{bangla}
29 October 2026 \quad | \quad Revised bilingual edition
\vspace{5mm}
\begin{bangla}
এটি NPA রাজনৈতিক সেলে আলোচনার জন্য ব্যক্তিগত প্রস্তাব; সংগঠনের অনুমোদিত অবস্থান নয়। বাংলা ও ইংরেজি অংশে একই মূল প্রস্তাব দেওয়া হয়েছে।
\end{bangla}
This is a personal proposal for discussion in the NPA Political Cell, not an adopted organisational position. Both language sections contain the same core proposal.\par
\vspace{4mm}
{\bfseries Reading guide}\par
\hyperlink{bangla}{Bangla: historical background, then the proposal}\par
\hyperlink{english}{English: historical background, then the proposal}\par
\hyperlink{references}{Shared references and source notes}\par
\vfill
\begin{bangla}১১টি নির্বাচিত ইতিহাস · ১৩টি তথ্যসূত্র · দুই ভাষায় পূর্ণ প্রস্তাব।\end{bangla}
Historical summaries are referenced; interpretations and proposed policies are identified separately.
\clearpage
'''
web={}
for lang,label in [('bn','বাংলা সংস্করণ'),('en','English edition')]:
 if lang=='bn':tex+='\\begin{bangla}\n'
 tex+='\\hypertarget{'+('bangla' if lang=='bn' else 'english')+'}{}\n'
 tex+=h(label,1,'Bangla edition' if lang=='bn' else 'English edition')
 tex+=h('পটভূমি: নির্বাচিত তৃণমূল ও গণআন্দোলনের ইতিহাস' if lang=='bn' else 'Background: selected grassroots and mass-movement histories',1)
 tex+=para(intro[lang]);w=['<h2>'+label+'</h2>','<h3>'+('ঐতিহাসিক পটভূমি' if lang=='bn' else 'Historical background')+'</h3>','<p>'+html.escape(intro[lang])+'</p>']
 for i,x in enumerate(hist):
  group= 'বাংলাদেশ ও অবিভক্ত বাংলার অভিজ্ঞতা' if i==0 else 'ভারতীয় উপমহাদেশের আরও অভিজ্ঞতা' if i==5 else 'বিশ্বের অন্যান্য অঞ্চলের অভিজ্ঞতা' if i==8 else None
  if lang=='en':group='Bangladesh and undivided Bengal' if i==0 else 'Other experiences from the Indian subcontinent' if i==5 else 'Other regions of the world' if i==8 else None
  if group:tex+=h(group,1);w.append('<h3>'+group+'</h3>')
  tex+=h(x[lang],2)+para(x[lang+'_text'])+para(x[lang+'_note'])
  w.extend(['<h4>'+html.escape(x[lang])+'</h4>','<p>'+html.escape(x[lang+'_text'])+'</p>','<p class="interpretation">'+html.escape(x[lang+'_note'])+'</p>'])
 tex+=para(synthesis[lang]);w.append('<p class="interpretation">'+html.escape(synthesis[lang])+'</p>')
 tex+=h('নীতিগত প্রস্তাব' if lang=='bn' else 'The policy proposal',1)
 md=bn if lang=='bn' else en;tex+=mdtex(md,lang)
 inlist=False;w.append('<h3>'+('নীতিগত প্রস্তাব' if lang=='bn' else 'The policy proposal')+'</h3>')
 for line in md.splitlines():
  if inlist and not line.startswith('- '):w.append('</ul>');inlist=False
  if line.startswith('# '):continue
  if line.startswith('## '):w.append('<h3>'+html.escape(line[3:])+'</h3>')
  elif line.startswith('### '):w.append('<h4>'+html.escape(line[4:])+'</h4>')
  elif line.startswith('- '):
   if not inlist:w.append('<ul>');inlist=True
   w.append('<li>'+html.escape(line[2:])+'</li>')
  elif line:w.append('<p>'+html.escape(line)+'</p>')
 if inlist:w.append('</ul>')
 joined='\n'.join(w);joined=re.sub(r'\[([0-9,]+)\]',lambda m:'['+', '.join(f'<a href="#ref{n}">{n}</a>' for n in m[1].split(','))+']',joined);web[lang]=joined
 if lang=='bn':tex+='\\end{bangla}\n'
 tex+='\\clearpage\n'
tex+='\\hypertarget{references}{}\n'+h('References and source notes',1,'References')
tex+=para('Sources checked on 29 October 2026. Historical summaries are paraphrases. Banglapedia provides scholarly reference accounts; archive and research-institute sources provide historical documentation; SEWA and the Brazilian official biography are institutional accounts, not independent impact evaluations. The Oxford chapter abstract supports the broad RTI chronology. The OHCHR briefing reports human-rights findings, not a judicial determination of individual criminal guilt. Interpretations and policy proposals are the author’s discussion material.')
tex+='\\begin{bangla}\n'+para('সূত্রগুলো ২৯ অক্টোবর ২০২৬ যাচাই করা হয়েছে। ইতিহাসের অনুচ্ছেদগুলো সংক্ষিপ্ত ভাবানুবাদ; উৎসের সরাসরি উদ্ধৃতি নয়। প্রাতিষ্ঠানিক আত্মবিবরণ, গবেষণা এবং মানবাধিকার অনুসন্ধানের সীমা আলাদা। ঐতিহাসিক সূত্র নিচের ব্যক্তিগত নীতিপ্রস্তাবের অনুমোদন বোঝায় না।')+'\\end{bangla}\n'
rweb=['<h2 id="references">সূত্র / References</h2><p>Sources checked: 29 October 2026. Historical summaries are paraphrases. Institutional accounts are identified; interpretations and policy proposals are independent discussion material.</p>']
for i,(author,title,url) in enumerate(sources,1):
 tex+='\\hypertarget{ref'+str(i)+'}{}\n'+para(f'[{i}] {author}. {title}.')+'\\url{'+url+'}\n\n'
 rweb.append(f'<p id="ref{i}">[{i}] {html.escape(author)}. <a href="{html.escape(url,quote=True)}">{html.escape(title)}</a>.</p>')
tex+='\\end{document}\n';(root/(stem+'.tex')).write_text(tex)
css='''@font-face{font-family:NpaBengali;src:url("fonts/bengali-serif.woff") format("woff");font-display:swap} .bilingual-doc{max-width:850px;margin:auto;padding:40px 24px;color:#182d34}.bilingual-doc [lang="bn"]{font-family:NpaBengali,"Noto Serif Bengali",serif;font-size:20px;line-height:1.95;letter-spacing:normal;word-spacing:normal;text-align:left}.bilingual-doc [lang="en"]{font-family:Georgia,"Times New Roman",serif;font-size:19px;line-height:1.8;text-align:left}.bilingual-doc h1[lang="bn"]{font-size:clamp(1.9rem,5vw,2.7rem)}.bilingual-doc h2,.bilingual-doc h3,.bilingual-doc h4{white-space:normal}.bilingual-doc h1{font-size:clamp(1.9rem,5vw,2.7rem);line-height:1.55;white-space:normal}.bilingual-doc h2{margin-top:2.5rem;line-height:1.6}.bilingual-doc h3{margin-top:2.3rem;line-height:1.6}.bilingual-doc h4{font-size:1.16em;margin:1.8rem 0 .7rem;line-height:1.6}.bilingual-doc p{margin:0 0 1.2rem}.bilingual-doc li{margin-bottom:.6rem}.bilingual-doc section{padding:0;border:0;scroll-margin-top:24px}.bilingual-doc .interpretation{border-left:3px solid #8caeb0;padding-left:16px}.bilingual-doc .language-nav{display:flex;gap:16px;flex-wrap:wrap;padding:18px 0}.bilingual-doc .notice{padding:20px;background:#edf4f3;border:1px solid #c7d8d6}.bilingual-doc #references{scroll-margin-top:30px}.bilingual-doc a{overflow-wrap:anywhere}@media(max-width:600px){.bilingual-doc{padding:28px 18px}.bilingual-doc [lang="bn"]{font-size:19px}.bilingual-doc [lang="en"]{font-size:18px}}@media print{header,footer,.language-nav{display:none}.bilingual-doc{max-width:none;padding:0}.bilingual-doc [lang="bn"]{font-size:12pt}.bilingual-doc [lang="en"]{font-size:11pt}.bilingual-doc h3,.bilingual-doc h4{break-after:avoid}}'''
(site/'npa-proposal.css').write_text(css)
page='''<!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>তৃণমূলের ইতিহাস ও জনচাহিদা | Grassroots Histories and Public Needs | Making Sense</title><meta name="description" content="বাংলা–ইংরেজি ব্যক্তিগত প্রস্তাব: বাংলাদেশ, ভারতীয় উপমহাদেশ ও বিশ্বের তৃণমূল আন্দোলনের ইতিহাস; জনচাহিদা ও সামাজিক অধিকার।"><link rel="stylesheet" href="style.css"><link rel="stylesheet" href="refresh.css"><link rel="stylesheet" href="npa-proposal.css"></head><body><a class="skip" href="#main">মূল লেখায় যান</a><header><a class="brand" href="/making-sense/">Making Sense with Ikramul</a><nav aria-label="প্রধান মেনু"><a href="/making-sense/">প্রথম পাতা</a><a href="society.html">সমাজ ও ভাবনা</a><a href="society.html#npa-political">NPA · Political</a></nav></header><main id="main" class="bilingual-doc"><p>NPA / Political · Personal discussion proposal</p><h1 lang="bn">তৃণমূল আন্দোলনের ইতিহাস, জনচাহিদা ও সামাজিক অধিকার</h1><p lang="en">Grassroots Histories, Public Needs and Social Rights</p><p lang="bn">মো. ইকরামুল হক খান · সংশোধিত দ্বিভাষিক সংস্করণ · ২৯ অক্টোবর ২০২৬</p><div class="notice"><p lang="bn">ব্যক্তিগত আলোচনার প্রস্তাব; NPA-এর অনুমোদিত অবস্থান নয়। ইতিহাসের তথ্য, পাঠের ব্যাখ্যা ও নীতিপ্রস্তাব আলাদা করে উপস্থাপিত।</p><p lang="en">A personal proposal, not an adopted NPA position. Historical summaries, interpretations and policy proposals are presented separately.</p></div><nav class="language-nav" aria-label="ভাষা ও ডাউনলোড"><a href="#bangla">বাংলা পড়ুন</a><a href="#english">Read in English</a><a href="#references">সূত্র / References</a><a href="documents/NPA_Public_Needs_Bangla.pdf">Bilingual PDF</a><a href="documents/NPA_Public_Needs_Bangla_LaTeX.zip">LaTeX source</a></nav><section id="bangla" lang="bn">'''+web['bn']+'''</section><nav class="language-nav"><a href="#english">Read the English edition ↓</a><a href="#main">শুরুতে ফিরুন ↑</a></nav><section id="english" lang="en">'''+web['en']+'''</section><section lang="en">'''+''.join(rweb)+'''</section><p><a href="society.html#npa-political">NPA রাজনৈতিক আলোচনা বিভাগে ফিরুন</a></p></main><footer><p>© 2026 Md. Ikramul Haq Khan · Personal proposal; not an adopted NPA position.</p></footer></body></html>'''
(site/'npa-public-needs-proposal.html').write_text(page)
soc=Path('current-society.html').read_text();soc=soc.replace('দীর্ঘমেয়াদি জনচাহিদা ও সামাজিক অধিকার কর্মসূচি</h3>','তৃণমূলের ইতিহাস, জনচাহিদা ও সামাজিক অধিকার · বাংলা–English</h3>',1);soc=soc.replace('প্রবাসী সেবা, কর্মক্ষেত্রের নিরাপত্তা, শিশুযত্ন, শিক্ষা, কৃষি, ক্রয়ক্ষমতা, সাংস্কৃতিক অধিকার ও প্রগতিশীল অর্থায়ন নিয়ে জনপরামর্শ ও জবাবদিহির প্রস্তাব।','বাংলাদেশ, ভারতীয় উপমহাদেশ ও বিশ্বের ১১টি আন্দোলনের সূত্রভিত্তিক পটভূমি; এরপর প্রবাসী সেবা, শ্রম, শিক্ষা, কৃষি, ক্রয়ক্ষমতা ও সামাজিক অধিকার নিয়ে পূর্ণ বাংলা–ইংরেজি ব্যক্তিগত প্রস্তাব।',1);soc=soc.replace('সম্পূর্ণ বাংলা প্রস্তাব পড়ুন →','দ্বিভাষিক প্রস্তাব ও ইতিহাস পড়ুন →',1).replace('>বাংলা PDF</a>','>বাংলা–English PDF</a>',1);(site/'society.html').write_text(soc)
shutil.copy(site/'fonts/OFL.txt',root/'OFL.txt')
(root/'README.txt').write_text('Bilingual revised proposal\n\nCompile twice with XeLaTeX:\n  xelatex NPA_Public_Needs_Bangla.tex\n\nKeep BengaliSerif.ttf beside the .tex file. Noto Serif Bengali is bundled under the SIL Open Font License (OFL.txt). The explicit Script=Bengali setting enables correct conjunct and vowel shaping; the font uses its default OpenType language system. Latin Modern Roman is supplied by standard TeX installations.\n\nThe filename is retained for stable website links; this edition contains both Bangla and English. Source data, original Bangla proposal, English translation and historical references are included.\n')
