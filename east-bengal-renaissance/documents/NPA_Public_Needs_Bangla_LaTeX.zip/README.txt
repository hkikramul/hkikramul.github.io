Bilingual revised proposal

Compile twice with XeLaTeX:
  xelatex NPA_Public_Needs_Bangla.tex

Keep BengaliSerif.ttf beside the .tex file. Noto Serif Bengali is bundled under the SIL Open Font License (OFL.txt). The explicit Script=Bengali setting enables correct conjunct and vowel shaping; the font uses its default OpenType language system. Latin Modern Roman is supplied by standard TeX installations.

The filename is retained for stable website links; this edition contains both Bangla and English. Source data, original Bangla proposal, English translation and historical references are included.
