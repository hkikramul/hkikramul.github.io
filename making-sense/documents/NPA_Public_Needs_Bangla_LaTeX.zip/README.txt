Compile with XeLaTeX: xelatex NPA_Public_Needs_Bangla.tex
Run twice. The bundled Noto Sans Bengali font is included for reproducible Bengali shaping.
